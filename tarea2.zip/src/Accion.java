

public interface Accion{
  void execute(Pluma p);
  
  void addAccion(Accion a);
  
}

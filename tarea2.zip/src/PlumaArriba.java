

public class PlumaArriba implements Condiciones{

  public boolean execute(Pluma p) {
    return p.arriba == true;
  }
}

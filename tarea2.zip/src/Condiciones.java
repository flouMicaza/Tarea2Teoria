

public interface Condiciones {
  public boolean execute(Pluma p);
}
